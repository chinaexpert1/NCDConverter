using System.Windows;

namespace NCDConverter
{
    public partial class App : Application
    {
    }
}
